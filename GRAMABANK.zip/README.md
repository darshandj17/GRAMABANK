# GramBank AI — Hackathon Rebuilt Edition

## What changed
This rebuild is designed for today's hackathon submission and web-to-APK conversion.

### Major fixes
- Replaced the OpenAI API integration with **Google Gemini API** support.
- Default Gemini model field: `gemini-2.5-flash` (editable in Profile).
- Added a **working demo fallback**: common questions can still receive answers without an API key.
- AI Assistant supports English, local-language selection, Romanized/code-mixed questions, and voice input.
- Policy Simplifier: AI structured explanation + verification reminder.
- Fraud Shield: risk classification + safety actions.
- Scheme Finder: profile-based educational matching + official MyScheme verification link.
- Voice Assistant: speech recognition + speech synthesis.
- Financial Learning: interactive quiz, score, explanations.
- Profile: Gemini API configuration and accessibility controls.
- Admin Console: local verified-content registry, add-item workflow, audit log, statistics and clear-log action.
- Added distinctive visual/illustration elements for each section using CSS so the ZIP remains self-contained and lightweight.
- No login/signup.
- No collection of OTP/PIN/CVV/passwords.
- No transaction execution.
- Added `manifest.json` for a cleaner web/PWA-style experience.

## Run
Open `index.html` in Chrome/Edge.

For microphone features, use a local server:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Gemini setup
1. Create a Gemini API key in Google AI Studio.
2. Open **Profile & AI** in GramBank AI.
3. Paste the key and save.
4. The app will try Gemini first.
5. If Gemini is unavailable, the app automatically falls back to built-in demo answers.

### Important
This browser-side API-key design is for a **hackathon/demo prototype only**. Do not ship a private production API key in frontend code. Production should call Gemini through a secure backend.

## Convert to APK
Upload this ZIP to a no-login HTML/ZIP-to-APK converter. The ZIP contains `index.html` at its root, which is the expected entry point.

## Safety
This prototype is financial-literacy software, not a banking transaction system. Always verify current policy, fee, eligibility and scheme information through official sources.


## FINAL BUILD NOTES
### Microphone
The app now explicitly requests `getUserMedia({audio:true})` before starting speech recognition. If the APK wrapper supports microphone permissions, Android should show the permission prompt. If the wrapper's WebView does not expose SpeechRecognition, the app clearly reports that limitation instead of silently doing nothing.

For the APK: Android Settings → Apps → GramBank AI → Permissions → Microphone → Allow.

### Gemini Save & Test
"Save & test Gemini" now performs a real `generateContent` request. It reports success or the exact API error instead of silently saving the key. "Find available model" queries Gemini's models endpoint and chooses a model that supports `generateContent`.

### Language
The selected language is used for Gemini system instructions and voice recognition/speech output. Demo fallback also changes language messaging rather than always returning identical English text.

Google's current Gemini REST API uses the `models.generateContent` endpoint. API keys must be active and appropriately restricted for Gemini API access. See the official Gemini documentation before a production deployment.
